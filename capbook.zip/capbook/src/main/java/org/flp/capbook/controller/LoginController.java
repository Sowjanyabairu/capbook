package org.flp.capbook.controller;

import java.util.List;

import org.flp.capbook.model.Login;
import org.flp.capbook.service.ILoginService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class LoginController {
	
	@Autowired
	private ILoginService  LoginService;
	
	
	@GetMapping("/login")
	private ResponseEntity<List<Login>> getLogins(){
		List<Login> login=LoginService.getAllLogins();
		
		return new ResponseEntity<List<Login>>(login, HttpStatus.OK);
	}
	
	
	@PostMapping("/login")
	public ResponseEntity<List<Login>> saveLogin(@RequestBody Login login){
		
		List<Login> logins= LoginService.saveLogin(login);
		if(logins.isEmpty())
		{
			return new ResponseEntity("Sorry! Logins  are not available!", 
   				HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Login>>(logins, HttpStatus.OK);
		
	}
		
	
}

