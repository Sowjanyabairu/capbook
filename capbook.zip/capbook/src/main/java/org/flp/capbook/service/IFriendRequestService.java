package org.flp.capbook.service;

import java.util.List;

import org.flp.capbook.model.Friend_request;
import org.flp.capbook.model.UserProfile;



public interface IFriendRequestService {


   List<Friend_request> getAllFriendRequests(Integer userId);

}
