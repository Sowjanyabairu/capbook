package org.flp.capbook.service;

import java.util.List;

import org.flp.capbook.dao.IFriendRequestDao;
import org.flp.capbook.model.Friend_request;
import org.flp.capbook.model.UserProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("FriendRequestService")
public class FriendRequestService implements IFriendRequestService{
	
	
	@Autowired
	private  IFriendRequestDao friendrequestdao;

	@Override
	public List<Friend_request> getAllFriendRequests(Integer receiverId) {
		// TODO Auto-generated method stub
		return friendrequestdao.getAllFriendrequest(receiverId);
	}

	

	
}
