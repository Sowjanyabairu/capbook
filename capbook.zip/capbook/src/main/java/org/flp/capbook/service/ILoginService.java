package org.flp.capbook.service;

import java.util.List;

import org.flp.capbook.model.Login;

public interface ILoginService {
	List<Login> getAllLogins();



	List<Login> saveLogin(Login login);



}
