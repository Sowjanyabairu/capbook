package org.flp.capbook.controller;

import java.util.List;

import org.flp.capbook.model.Friend_request;
import org.flp.capbook.model.UserProfile;
import org.flp.capbook.service.IFriendRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class FriendRequestController {
	
	@Autowired
	private IFriendRequestService FriendRequestService;
	
	
	@GetMapping("/request/{userId}")
	private ResponseEntity<List<Friend_request>> getFriendrequests(@PathVariable("userId") Integer userId){
		List<Friend_request> request=FriendRequestService.getAllFriendRequests(userId);
		
		return new ResponseEntity<List<Friend_request>>(request, HttpStatus.OK);
	}
	
	

}
